import redis

try:
    client = redis.Redis(host="localhost", port=6379, db=0)
    response = client.ping()
    if response:
        print("Redis is running and accessible.")
except Exception as e:
    print(f"Failed to connect to Redis: {e}")
