#!/bin/bash

# Project Setup
PROJECT_NAME="openai_relay_bot"
VENV_PATH="/mnt/rasa/venv/bin/activate"

# Initialize Rasa Project
source $VENV_PATH
mkdir -p /mnt/rasa/$PROJECT_NAME
cd /mnt/rasa/$PROJECT_NAME
rasa init --no-prompt

# Clear Default Rasa Logic
rm -rf data tests models

# Create Custom Action
mkdir -p actions
cat <<EOF > actions/actions.py
from typing import Any, Text, Dict, List
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
import openai

openai.api_key = "YOUR_OPENAI_API_KEY"

class ActionTalkToOpenAI(Action):
    def name(self) -> Text:
        return "action_talk_to_openai"

    def run(self, dispatcher: CollectingDispatcher,
            tracker: Tracker,
            domain: Dict[Text, Any]) -> List[Dict[Text, Any]]:
        
        user_message = tracker.latest_message.get('text', '')
        
        response = openai.Completion.create(
            engine="text-davinci-003",
            prompt=user_message,
            max_tokens=150
        )

        answer = response['choices'][0]['text'].strip()
        dispatcher.utter_message(text=answer)
        return []
EOF

# Update Endpoints and Domain Files
cat <<EOF > endpoints.yml
action_endpoint:
  url: "http://localhost:5055/webhook"
EOF

cat <<EOF > domain.yml
actions:
  - action_talk_to_openai
EOF

# Start Action Server and Rasa Server
nohup rasa run actions --debug &> action_server.log &
nohup rasa run --enable-api --cors "*" --debug &> rasa_server.log &
echo "Rasa project setup completed."
