import openai
from actions.actions import ActionCallGPT4o
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk import Tracker

class TestDispatcher(CollectingDispatcher):
    def __init__(self):
        self.messages = []

    def utter_message(self, text=None, **kwargs):
        self.messages.append(text)

# Mock tracker with user message
tracker = Tracker(
    sender_id="test_user",
    slots={},
    latest_message={"text": "What is the capital of France?", "intent": {"name": "ask_gpt4o"}},
    events=[],
    paused=False,
    followup_action=None,
    active_loop=None,
    latest_action_name="action_listen"
)

# Initialize custom action and dispatcher
action = ActionCallGPT4o()
dispatcher = TestDispatcher()

# Run the action
action.run(dispatcher=dispatcher, tracker=tracker, domain={})

# Print the output messages
print("Messages from the action:")
for message in dispatcher.messages:
    print(message)
