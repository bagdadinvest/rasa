import os
import openai
from typing import Any, Dict, List, Text
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher

# Load OpenAI API Key from environment or set directly
openai.api_key = os.getenv("OPENAI_API_KEY", "sk-proj-8DjzNP4P32MqOsIjQL7pCd-nceOQii9LZ8vjnviFYvThbBjPSRV055LZWFapvLSCYLOFlmg1KvT3BlbkFJYwQ03jQdkoO1aV537qIYQYI7aA-B_hcBdkk5HY_ANgzyCWKfpdhgjv4Iyz1Up0z8MV6lMPWOs")

class ActionTalkToOpenAI(Action):
    def name(self) -> Text:
        return "action_talk_to_openai"

    def run(
        self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict[Text, Any]
    ) -> List[Dict[Text, Any]]:

        # Get the latest user message
        user_message = tracker.latest_message.get("text")

        try:
            # Use OpenAI's ChatCompletion API
            response = openai.ChatCompletion.create(
                model="gpt-4",  # Use GPT-4 or the preferred model
                messages=[
                    {"role": "system", "content": "You are a helpful AI assistant."},
                    {"role": "user", "content": user_message},
                ],
                max_tokens=1500,
                temperature=0.7,
            )

            # Extract AI response
            ai_response = response["choices"][0]["message"]["content"].strip()

            # Send the response back to the user
            dispatcher.utter_message(text=ai_response)

        except Exception as e:
            error_msg = f"Failed to fetch response: {e}"
            dispatcher.utter_message(text=error_msg)

        return []
